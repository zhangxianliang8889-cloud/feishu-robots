#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""群会议纪要测试脚本 - 使用主程序完整逻辑"""

import requests
import json
import re
from datetime import datetime, timedelta
from collections import Counter
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import *

NO_PROXY = {}

def get_feishu_token():
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    data = {"app_id": FEISHU_APP_ID, "app_secret": FEISHU_APP_SECRET}
    try:
        r = requests.post(url, json=data, timeout=10, proxies=NO_PROXY)
        r.raise_for_status()
        response = r.json()
        if "tenant_access_token" in response:
            return response["tenant_access_token"]
        else:
            print(f"❌ 获取Token失败: {response}")
            return None
    except Exception as e:
        print(f"❌ 获取Token时发生错误: {e}")
        return None

def get_bot_groups(token):
    url = "https://open.feishu.cn/open-apis/im/v1/chats"
    headers = {"Authorization": f"Bearer {token}"}
    params = {"page_size": 100}
    
    try:
        r = requests.get(url, headers=headers, params=params, timeout=10, proxies=NO_PROXY)
        r.raise_for_status()
        response = r.json()
        
        if response.get("code") == 0:
            data = response.get("data", {})
            return data.get("items", [])
        else:
            print(f"⚠️ 获取群列表失败: {response}")
            return []
    except Exception as e:
        print(f"⚠️ 获取群列表时发生错误: {e}")
        return []

def get_group_members(token, chat_id):
    if not token or not chat_id:
        return {}
    
    url = f"https://open.feishu.cn/open-apis/im/v1/chats/{chat_id}/members"
    headers = {"Authorization": f"Bearer {token}"}
    params = {"page_size": 100}
    
    members_map = {}
    page_token = None
    
    try:
        while True:
            if page_token:
                params["page_token"] = page_token
            
            r = requests.get(url, headers=headers, params=params, timeout=10, proxies=NO_PROXY)
            r.raise_for_status()
            response = r.json()
            
            if response.get("code") == 0:
                data = response.get("data", {})
                items = data.get("items", [])
                
                for item in items:
                    member_id = item.get("member_id", "")
                    name = item.get("name", "未知")
                    if member_id:
                        members_map[member_id] = name
                
                page_token = data.get("page_token")
                if not page_token:
                    break
            else:
                break
    except Exception as e:
        print(f"⚠️ 获取群成员时发生错误: {e}")
    
    return members_map

def get_recent_messages(token, chat_id, hours=24):
    if not token or not chat_id:
        return []
    
    now = datetime.now()
    start_time = now - timedelta(hours=hours)
    
    start_ts = int(start_time.timestamp() * 1000)
    end_ts = int(now.timestamp() * 1000)
    
    url = "https://open.feishu.cn/open-apis/im/v1/messages"
    headers = {"Authorization": f"Bearer {token}"}
    params = {
        "container_id": chat_id,
        "container_id_type": "chat",
        "page_size": 50
    }
    
    all_messages = []
    page_token = None
    
    try:
        while True:
            if page_token:
                params["page_token"] = page_token
            
            r = requests.get(url, headers=headers, params=params, timeout=10, proxies=NO_PROXY)
            r.raise_for_status()
            response = r.json()
            
            if response.get("code") != 0:
                print(f"⚠️ API返回错误: {response}")
                break
            
            data = response.get("data", {})
            messages = data.get("items", [])
            
            for msg in messages:
                create_time = int(msg.get("create_time", 0))
                if start_ts <= create_time <= end_ts:
                    all_messages.append(msg)
            
            if not data.get("has_more", False):
                break
            
            page_token = data.get("page_token")
            
    except Exception as e:
        print(f"❌ 获取消息时发生错误: {e}")
    
    return all_messages

def extract_chat_records(messages, members_map=None):
    if members_map is None:
        members_map = {}
    
    records = []
    for msg in messages:
        msg_type = msg.get("msg_type")
        if msg_type == "text":
            body = msg.get("body", {})
            content_str = body.get("content", "{}")
            try:
                content = json.loads(content_str)
                text = content.get("text", "").strip()
                if text:
                    sender_info = msg.get("sender", {})
                    sender_id = sender_info.get("id", "未知")
                    sender_type = sender_info.get("sender_type", "")
                    sender_name = members_map.get(sender_id, sender_id[:8] if sender_id else "未知")
                    
                    if sender_type == "app" or sender_id.startswith("cli_") or "机器人" in sender_name or sender_name.startswith("cli_"):
                        continue
                    
                    time_str = datetime.fromtimestamp(int(msg.get("create_time", 0))//1000).strftime("%H:%M")
                    records.append({
                        "time": time_str,
                        "sender": sender_name,
                        "content": text
                    })
            except json.JSONDecodeError:
                text = content_str.strip()
                if text and text != "None":
                    time_str = datetime.fromtimestamp(int(msg.get("create_time", 0))//1000).strftime("%H:%M")
                    records.append({
                        "time": time_str,
                        "sender": "未知",
                        "content": text
                    })
    return records

def format_chat_text(records):
    lines = []
    for record in records:
        lines.append(f"[{record['time']}] {record['sender']}: {record['content']}")
    return lines

def generate_ai_summary(lines, total_messages, summary_type="daily", chat_name="", date_range=""):
    """使用主程序的完整AI总结逻辑"""
    participants = set()
    tasks = []
    decisions = []
    important_info = []
    questions = []
    suggestions = []
    links = []
    keywords = []
    topics = []
    
    task_patterns = [
        r'需要(.{2,20})',
        r'要(.{2,20})',
        r'请(.{2,20})',
        r'帮忙(.{2,20})',
        r'完成(.{2,20})',
        r'处理(.{2,20})',
        r'跟进(.{2,20})',
        r'安排(.{2,20})',
        r'准备(.{2,20})',
        r'待办[:：](.{2,30})',
        r'TODO[:：](.{2,30})',
    ]
    
    decision_patterns = [
        r'确定(.{2,30})',
        r'同意(.{2,20})',
        r'确认(.{2,30})',
        r'定下来(.{2,20})',
        r'就这么定了',
        r'通过(.{2,20})',
    ]
    
    important_patterns = [
        r'重要[:：](.{2,50})',
        r'注意[:：](.{2,50})',
        r'提醒(.{2,30})',
        r'通知[:：](.{2,50})',
    ]
    
    question_patterns = [
        r'(.{2,10})\?',
        r'(.{2,10})？',
        r'怎么(.{2,20})',
        r'如何(.{2,20})',
        r'为什么(.{2,20})',
        r'有没有(.{2,20})',
    ]
    
    suggestion_patterns = [
        r'建议(.{2,30})',
        r'可以(.{2,20})',
        r'试试(.{2,20})',
        r'不如(.{2,20})',
        r'推荐(.{2,20})',
    ]
    
    stop_words = {'的', '了', '是', '在', '有', '和', '就', '不', '人', '都', 
                  '一', '一个', '上', '也', '很', '到', '说', '要', '去', '你',
                  '会', '着', '没有', '看', '好', '自己', '这', '那', '什么',
                  '吗', '呢', '吧', '啊', '嗯', '哦', '哈', '呀', '额', '这个',
                  '那个', '可以', '可能', '应该', '还是', '但是', '因为', '所以',
                  '大家', '早上好', '好的', '收到', '谢谢', '感谢', '没问题',
                  '今天', '明天', '昨天', '下午', '上午', '晚上', '几点', '开始',
                  '什么', '怎么', '哪里', '多少', '怎样', '如何', '为什么',
                  '总新闻数', 'AI分析数', '时间', '类型', '简报', '热点早报',
                  '测试推送', '老板专属', '每日资讯', 'This', 'message', 'was',
                  'recalled', '消息撤回', '═══', '════════', '════════════════════════════════════════'}
    
    for line in lines:
        match = re.match(r'\[(\d{2}:\d{2})\]\s*(.+?):\s*(.+)', line)
        if match:
            time, sender, content = match.groups()
            participants.add(sender)
            
            for pattern in task_patterns:
                task_match = re.search(pattern, content)
                if task_match:
                    tasks.append(task_match.group(0).strip())
                    break
            
            for pattern in decision_patterns:
                decision_match = re.search(pattern, content)
                if decision_match:
                    decisions.append(decision_match.group(0).strip())
                    break
            
            for pattern in important_patterns:
                info_match = re.search(pattern, content)
                if info_match:
                    important_info.append(info_match.group(0).strip())
                    break
            
            for pattern in question_patterns:
                q_match = re.search(pattern, content)
                if q_match:
                    questions.append(q_match.group(0).strip())
                    break
            
            for pattern in suggestion_patterns:
                s_match = re.search(pattern, content)
                if s_match:
                    suggestions.append(s_match.group(0).strip())
                    break
            
            url_match = re.search(r'https?://[^\s]+', content)
            if url_match:
                links.append(url_match.group(0))
            
            words = re.findall(r'[\u4e00-\u9fa5]{2,8}', content)
            for word in words:
                if (word not in stop_words and 
                    len(word) >= 2 and 
                    not word.startswith('关于') and
                    not re.match(r'^[0-9]+$', word) and
                    not word.startswith('═')):
                    keywords.append(word)
            
            if len(content) > 10 and not content.startswith('**') and 'http' not in content:
                clean_content = re.sub(r'[【\[\(].*?[\]\)】]', '', content)
                clean_content = re.sub(r'\*+', '', clean_content)
                clean_content = re.sub(r'═+', '', clean_content)
                clean_content = clean_content.strip()
                if len(clean_content) > 5 and clean_content not in ['This message was recalled']:
                    topics.append(clean_content[:30])
    
    keyword_freq = Counter(keywords).most_common(10)
    top_keywords = [word for word, _ in keyword_freq[:5]]
    
    participant_count = len(participants)
    
    return generate_daily_summary(participant_count, total_messages, topics, top_keywords, decisions, tasks, links, chat_name, date_range)

def generate_daily_summary(participant_count, total_messages, topics, top_keywords, decisions, tasks, links, chat_name="", date_range=""):
    """生成日报格式"""
    summary_parts = []
    
    if chat_name and date_range:
        summary_parts.append(f"📊 {chat_name} - 群会议纪要日报 ({date_range})")
        summary_parts.append("")
    
    summary_parts.append(f"📈 今日数据：{total_messages} 条消息 | {participant_count} 人参与")
    summary_parts.append("")
    if topics:
        unique_topics = []
        for t in topics[:10]:
            is_dup = False
            for ut in unique_topics:
                if t[:15] in ut or ut[:15] in t:
                    is_dup = True
                    break
            if not is_dup and len(unique_topics) < 5:
                unique_topics.append(t)
        
        for topic in unique_topics:
            summary_parts.append(f"• {topic}")
    elif top_keywords:
        for kw in top_keywords[:5]:
            summary_parts.append(f"• {kw}")
    else:
        summary_parts.append("• 暂无具体讨论内容")
    summary_parts.append("")
    
    summary_parts.append("✅ 完成事项：")
    if decisions:
        for d in decisions[:3]:
            summary_parts.append(f"• {d}")
    else:
        summary_parts.append("• 暂无")
    
    summary_parts.append("📋 待办事项：")
    if tasks:
        for t in tasks[:3]:
            summary_parts.append(f"• {t}")
    else:
        summary_parts.append("• 暂无")
    
    summary_parts.append("📎 相关链接：")
    if links:
        for link in links[:2]:
            summary_parts.append(f"• {link[:50]}...")
    else:
        summary_parts.append("• 暂无")
    summary_parts.append("")
    
    if top_keywords:
        summary_parts.append(f"💡 今日总结：群聊主要围绕「{'、'.join(top_keywords[:3])}」展开，共{participant_count}人参与。")
    else:
        summary_parts.append(f"💡 今日总结：共{participant_count}人参与，产生{total_messages}条消息。")
    
    if total_messages > 0:
        summary_parts.append("")
        summary_parts.append("🌟 感谢大家的积极参与！每一条消息都是智慧的火花！")
    else:
        summary_parts.append("")
        summary_parts.append("🔔 今天有点安静哦，期待大家分享想法和见解！")
    
    summary_parts.append("")
    summary_parts.append("🌈 这里是我们灵感碰撞的地方！💪 勇于表达，让群智涌现！")
    
    return '\n'.join(summary_parts)

def send_message_to_group(token, chat_id, message_content):
    url = "https://open.feishu.cn/open-apis/im/v1/messages"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    params = {
        "receive_id_type": "chat_id"
    }
    
    data = {
        "receive_id": chat_id,
        "msg_type": "text",
        "content": json.dumps({"text": message_content})
    }
    
    try:
        r = requests.post(url, headers=headers, params=params, json=data, timeout=10, proxies=NO_PROXY)
        r.raise_for_status()
        result = r.json()
        
        if result.get("code") == 0:
            return True
        else:
            print(f"❌ 消息发送失败: {result}")
            return False
    except Exception as e:
        print(f"❌ 发送消息时发生错误: {e}")
        return False

def main():
    print("=" * 60)
    print("🧪 群会议纪要测试脚本（完整版）")
    print("=" * 60)
    print()
    
    print("🔑 获取飞书Token...")
    token = get_feishu_token()
    if not token:
        print("❌ Token获取失败，退出")
        return
    print("✅ Token获取成功")
    print()
    
    print("📋 获取机器人所在群列表...")
    groups = get_bot_groups(token)
    print(f"✅ 机器人共在 {len(groups)} 个群中")
    print()
    
    test_group = None
    for group in groups:
        if group.get("name") == "张贤良测试群":
            test_group = group
            break
    
    if not test_group:
        print("❌ 未找到张贤良测试群")
        return
    
    chat_id = test_group.get("chat_id")
    chat_name = test_group.get("name")
    print(f"🎯 找到测试群: {chat_name}")
    print(f"   Chat ID: {chat_id}")
    print()
    
    print("👥 获取群成员...")
    members_map = get_group_members(token, chat_id)
    print(f"✅ 获取到 {len(members_map)} 位群成员")
    print()
    
    print("💬 获取最近24小时消息...")
    messages = get_recent_messages(token, chat_id, hours=24)
    print(f"✅ 获取到 {len(messages)} 条消息")
    print()
    
    print("📝 提取聊天记录...")
    records = extract_chat_records(messages, members_map)
    print(f"✅ 提取到 {len(records)} 条有效记录")
    print()
    
    print("📝 生成会议纪要（使用主程序完整逻辑）...")
    lines = format_chat_text(records)
    date_range = datetime.now().strftime('%Y-%m-%d')
    summary = generate_ai_summary(lines, len(records), summary_type="daily", chat_name=chat_name, date_range=date_range)
    print("✅ 会议纪要生成完成")
    print()
    
    print("📤 发送会议纪要到测试群...")
    if send_message_to_group(token, chat_id, summary):
        print("✅ 发送成功！")
    else:
        print("❌ 发送失败")
    
    print()
    print("=" * 60)
    print("🎉 测试完成")
    print("=" * 60)

if __name__ == "__main__":
    main()
