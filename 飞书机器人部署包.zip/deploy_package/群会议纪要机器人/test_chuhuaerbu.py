#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试策划二部群内容，发送到测试群
包含两个机器人的测试：群会议纪要机器人 + 群消息统计机器人
"""

import sys
import os
from datetime import datetime, timedelta
import json
import calendar
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from 群会议纪要_最终版 import (
    get_feishu_token,
    get_bot_groups,
    get_messages_by_time_range,
    get_group_members,
    extract_chat_records,
    format_chat_text,
    local_summarize,
    send_message_to_group
)

from config import *

def get_chat_id_by_name(groups, name):
    """根据群名获取聊天ID"""
    for group in groups:
        if group.get("name") == name:
            return group.get("chat_id")
    return None

def get_messages_by_date_range(token, chat_id, days_back=1):
    """获取指定日期范围的消息"""
    now = datetime.now()
    
    if days_back == 1:
        start_time = now - timedelta(hours=24)
        end_time = now
    elif days_back == 7:
        monday = now - timedelta(days=now.weekday())
        start_time = monday - timedelta(weeks=1)
        end_time = monday
    else:
        first_of_month = now.replace(day=1)
        start_time = (first_of_month - timedelta(days=1)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        end_time = first_of_month
    
    start_ts = int(start_time.timestamp() * 1000)
    end_ts = int(end_time.timestamp() * 1000)
    
    messages = get_messages_by_time_range(token, chat_id, start_ts, end_ts)
    
    return messages, start_time, end_time

def generate_and_send_meeting_report(token, source_chat_id, source_chat_name, target_chat_id, summary_type, days_back):
    """生成并发送会议纪要报告"""
    print(f"\n{'='*80}")
    print(f"📊 群会议纪要机器人 - 生成 {summary_type}")
    print(f"   来源群: {source_chat_name}")
    print(f"   目标群: 张贤良测试群")
    print(f"{'='*80}")
    
    messages, start_time, end_time = get_messages_by_date_range(token, source_chat_id, days_back)
    print(f"✅ 获取到 {len(messages)} 条消息")
    
    members_map = get_group_members(token, source_chat_id)
    print(f"✅ 获取到 {len(members_map)} 位群成员")
    
    records = extract_chat_records(messages, members_map)
    print(f"✅ 提取到 {len(records)} 条文本消息")
    
    if summary_type == "daily":
        date_range = start_time.strftime('%Y-%m-%d')
    elif summary_type == "weekly":
        date_range = f"{start_time.strftime('%Y-%m-%d')} ~ {(end_time - timedelta(days=1)).strftime('%Y-%m-%d')}"
    else:
        date_range = start_time.strftime('%Y-%m')
    
    chat_text = format_chat_text(records)
    ai_summary_result = local_summarize(chat_text, summary_type, source_chat_name, date_range, len(records))
    
    if isinstance(ai_summary_result, dict):
        if not ai_summary_result.get("success"):
            print("❌ 总结生成失败")
            return False
        ai_summary = ai_summary_result.get("content", "")
    else:
        ai_summary = ai_summary_result
    
    if not ai_summary or len(ai_summary) < 50:
        print("❌ 总结内容过短或为空")
        return False
    
    footer = f"\n⏰ 生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n🤖 由群会议纪要机器人自动生成（测试版）"
    
    message_content = f"""{ai_summary}
{footer}
""".strip()
    
    print("\n📤 发送到测试群...")
    if send_message_to_group(token, target_chat_id, message_content):
        print(f"✅ 发送成功！")
        return True
    else:
        print(f"❌ 发送失败")
        return False

def generate_daily_report(count, title, date_range, group_name, sorted_count, total, active_count, total_members, active_rate):
    """生成日报格式（正式版本）"""
    report = f"📊 {group_name} - 群消息日报 ({date_range})\n\n"
    
    report += f"📈 今日数据：{total} 条消息 | {active_count}/{total_members} 人活跃 ({active_rate:.0f}%)\n\n"
    
    if total > 0:
        top3 = sorted_count[:3]
        report += "🏆 今日之星："
        medals = ["🥇", "🥈", "🥉"]
        star_list = [f"{medals[i]}{name}({cnt}条)" for i, (name, cnt) in enumerate(top3) if cnt > 0]
        report += " ".join(star_list) + "\n\n"
    
    report += "📋 全员榜单：\n"
    for i, (name, cnt) in enumerate(sorted_count, 1):
        if cnt > 0:
            emoji = "🔥" if cnt >= 10 else "💬" if cnt >= 5 else "💭"
            report += f"   {i}. {name}: {cnt}条 {emoji}\n"
        else:
            report += f"   {i}. {name}: 0条 💤\n"
    
    if active_rate >= 80:
        report += "\n🌟 今日群氛围火热！大家交流积极，群智涌现！\n"
    elif active_rate >= 50:
        report += "\n💪 今日交流不错！继续保持，期待更多伙伴加入讨论！\n"
    elif active_rate > 0:
        report += "\n📢 欢迎更多伙伴参与交流，每一条消息都是智慧的火花！\n"
    else:
        report += "\n🔔 今天有点安静哦，期待大家分享想法和见解！\n"
    
    silent_members = [name for name, cnt in sorted_count if cnt == 0]
    if silent_members:
        report += f"\n💌 期待你的声音：{', '.join(silent_members[:3])}\n"
        report += "   你的想法对我们很重要，期待听到你的分享！\n"
    
    report += "\n🌈 这里是我们灵感碰撞的地方！💪 勇于表达，让群智涌现！\n"
    
    footer_parts = []
    footer_parts.append(f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    footer_parts.append(f"🤖 群消息统计机器人（测试版）")
    
    if footer_parts:
        report += " | ".join(footer_parts) + "\n"
    
    return report

def generate_weekly_report(count, title, date_range, group_name, sorted_count, total, active_count, total_members, active_rate):
    """生成周报格式（正式版本）"""
    report = f"📊 {group_name} - 群消息周报 ({date_range})\n\n"
    
    report += f"📈 本周数据：{total} 条消息 | {active_count}/{total_members} 人活跃 ({active_rate:.0f}%) | 日均 {total // 7 if total > 0 else 0} 条\n\n"
    
    if total > 0:
        top5 = [x for x in sorted_count[:5] if x[1] > 0]
        if top5:
            report += "🏆 本周贡献榜："
            medals = ["🥇", "🥈", "🥉", "🏅", "🏅"]
            star_list = [f"{medals[i]}{name}({cnt}条)" for i, (name, cnt) in enumerate(top5)]
            report += " ".join(star_list) + "\n\n"
    
    report += "📋 全员周榜：\n"
    for i, (name, cnt) in enumerate(sorted_count, 1):
        if cnt > 0:
            avg_daily = cnt / 7
            emoji = "🔥" if avg_daily >= 5 else "💬" if avg_daily >= 2 else "💭"
            report += f"   {i}. {name}: {cnt}条 (日均{avg_daily:.1f}) {emoji}\n"
        else:
            report += f"   {i}. {name}: 0条 💤\n"
    
    if active_rate >= 80:
        report += "\n🌟 本周群氛围超棒！团队协作紧密，群智涌现！\n"
    elif active_rate >= 50:
        report += "\n💪 本周交流活跃！感谢每一位贡献者，下周继续加油！\n"
    elif active_rate > 0:
        report += "\n📢 期待更多伙伴加入讨论，思想的碰撞创造价值！\n"
    else:
        report += "\n🔔 本周有点安静，下周期待大家分享更多见解！\n"
    
    silent_members = [name for name, cnt in sorted_count if cnt == 0]
    if silent_members:
        report += f"\n💌 期待你的声音：{', '.join(silent_members[:3])}\n"
        report += "   本周没有看到你的发言，期待下周听到你的想法！\n"
    
    active_members = [name for name, cnt in sorted_count[:3] if cnt > 0]
    if active_members:
        report += f"\n🎉 特别感谢：{', '.join(active_members)}\n"
        report += "   你们的分享让群更有价值！\n"
    
    report += "\n🌈 这里是我们灵感碰撞的地方！💪 勇于表达，让群智涌现！\n"
    
    footer_parts = []
    footer_parts.append(f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    footer_parts.append(f"🤖 群消息统计机器人（测试版）")
    
    if footer_parts:
        report += " | ".join(footer_parts) + "\n"
    
    return report

def generate_monthly_report(count, title, date_range, group_name, sorted_count, total, active_count, total_members, active_rate):
    """生成月报格式（正式版本）"""
    report = f"📊 {group_name} - 群消息月报 ({date_range})\n\n"
    
    now = datetime.now()
    days_in_month = calendar.monthrange(now.year, now.month)[0] if now.month > 1 else calendar.monthrange(now.year - 1, 12)[1]
    
    report += f"📈 本月数据：{total} 条消息 | {active_count}/{total_members} 人活跃 ({active_rate:.0f}%) | 日均 {total // days_in_month if total > 0 else 0} 条\n\n"
    
    if total > 0:
        top5 = [x for x in sorted_count[:5] if x[1] > 0]
        if top5:
            report += "🏆 本月贡献榜："
            medals = ["🥇", "🥈", "🥉", "🏅", "🏅"]
            star_list = [f"{medals[i]}{name}({cnt}条)" for i, (name, cnt) in enumerate(top5)]
            report += " ".join(star_list) + "\n\n"
    
    report += "📋 全员月榜：\n"
    for i, (name, cnt) in enumerate(sorted_count, 1):
        if cnt > 0:
            avg_daily = cnt / days_in_month
            emoji = "🔥" if avg_daily >= 5 else "💬" if avg_daily >= 2 else "💭"
            report += f"   {i}. {name}: {cnt}条 (日均{avg_daily:.1f}) {emoji}\n"
        else:
            report += f"   {i}. {name}: 0条 💤\n"
    
    if active_rate >= 80:
        report += "\n🌟 本月群氛围超棒！团队协作紧密，群智涌现！\n"
    elif active_rate >= 50:
        report += "\n💪 本月交流活跃！感谢每一位贡献者，下月继续加油！\n"
    elif active_rate > 0:
        report += "\n📢 期待更多伙伴加入讨论，思想的碰撞创造价值！\n"
    else:
        report += "\n🔔 本月有点安静，下月期待大家分享更多见解！\n"
    
    silent_members = [name for name, cnt in sorted_count if cnt == 0]
    if silent_members:
        report += f"\n💌 期待你的声音：{', '.join(silent_members[:3])}\n"
        report += "   本月没有看到你的发言，期待下月听到你的想法！\n"
    
    active_members = [name for name, cnt in sorted_count[:3] if cnt > 0]
    if active_members:
        report += f"\n🎉 特别感谢：{', '.join(active_members)}\n"
        report += "   你们的分享让群更有价值！\n"
    
    report += "\n🌈 这里是我们灵感碰撞的地方！💪 勇于表达，让群智涌现！\n"
    
    footer_parts = []
    footer_parts.append(f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    footer_parts.append(f"🤖 群消息统计机器人（测试版）")
    
    if footer_parts:
        report += " | ".join(footer_parts) + "\n"
    
    return report

def generate_and_send_stats_report(token, source_chat_id, source_chat_name, target_chat_id, report_type, days_back):
    """生成并发送群消息统计报告（使用正式版本格式）"""
    print(f"\n{'='*80}")
    print(f"📊 群消息统计机器人 - 生成 {report_type}")
    print(f"   来源群: {source_chat_name}")
    print(f"   目标群: 张贤良测试群")
    print(f"{'='*80}")
    
    messages, start_time, end_time = get_messages_by_date_range(token, source_chat_id, days_back)
    print(f"✅ 获取到 {len(messages)} 条消息")
    
    members_map = get_group_members(token, source_chat_id)
    print(f"✅ 获取到 {len(members_map)} 位群成员")
    
    records = extract_chat_records(messages, members_map)
    print(f"✅ 提取到 {len(records)} 条文本消息")
    
    count = Counter(r['sender'] for r in records)
    sorted_count = count.most_common()
    
    total = len(records)
    active_count = len(count)
    total_members = len(members_map)
    active_rate = (active_count / total_members * 100) if total_members > 0 else 0
    
    if report_type == "日报":
        date_range = start_time.strftime('%Y-%m-%d')
        title = f"群消息日报 ({date_range})"
        report = generate_daily_report(count, title, date_range, source_chat_name, sorted_count, total, active_count, total_members, active_rate)
    elif report_type == "周报":
        date_range = f"{start_time.strftime('%Y-%m-%d')} ~ {(end_time - timedelta(days=1)).strftime('%Y-%m-%d')}"
        title = f"群消息周报 ({date_range})"
        report = generate_weekly_report(count, title, date_range, source_chat_name, sorted_count, total, active_count, total_members, active_rate)
    else:
        date_range = start_time.strftime('%Y-%m')
        title = f"群消息月报 ({date_range})"
        report = generate_monthly_report(count, title, date_range, source_chat_name, sorted_count, total, active_count, total_members, active_rate)
    
    print("\n📤 发送到测试群...")
    if send_message_to_group(token, target_chat_id, report):
        print(f"✅ 发送成功！")
        return True
    else:
        print(f"❌ 发送失败")
        return False

def main():
    print("=" * 80)
    print("🤖 策划二部群内容测试 - 两个机器人（正式版本格式）")
    print("=" * 80)
    
    token = get_feishu_token()
    if not token:
        print("❌ 获取token失败")
        return
    
    groups = get_bot_groups(token)
    
    source_chat_name = "策划二部"
    target_chat_name = "张贤良测试群"
    
    source_chat_id = get_chat_id_by_name(groups, source_chat_name)
    if not source_chat_id:
        print(f"❌ 未找到群组：{source_chat_name}")
        return
    
    target_chat_id = get_chat_id_by_name(groups, target_chat_name)
    if not target_chat_id:
        print(f"❌ 未找到群组：{target_chat_name}")
        return
    
    print(f"\n✅ 找到来源群: {source_chat_name}")
    print(f"✅ 找到目标群: {target_chat_name}")
    
    success_count = 0
    
    print("\n" + "=" * 80)
    print("🤖 机器人1：群会议纪要机器人")
    print("=" * 80)
    
    if generate_and_send_meeting_report(token, source_chat_id, source_chat_name, target_chat_id, "daily", 1):
        success_count += 1
    
    if generate_and_send_meeting_report(token, source_chat_id, source_chat_name, target_chat_id, "weekly", 7):
        success_count += 1
    
    if generate_and_send_meeting_report(token, source_chat_id, source_chat_name, target_chat_id, "monthly", 30):
        success_count += 1
    
    print("\n" + "=" * 80)
    print("🤖 机器人2：群消息统计机器人")
    print("=" * 80)
    
    if generate_and_send_stats_report(token, source_chat_id, source_chat_name, target_chat_id, "日报", 1):
        success_count += 1
    
    if generate_and_send_stats_report(token, source_chat_id, source_chat_name, target_chat_id, "周报", 7):
        success_count += 1
    
    if generate_and_send_stats_report(token, source_chat_id, source_chat_name, target_chat_id, "月报", 30):
        success_count += 1
    
    print(f"\n{'='*80}")
    print(f"📊 测试完成: ✅ {success_count}/6 个报告发送成功")
    print(f"{'='*80}")

if __name__ == "__main__":
    main()
