#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI智能总结模块 - 使用火山引擎豆包API
真正的智能总结，而不是简单摘抄
"""

import os
import json
import re
from typing import List, Dict, Any, Optional

try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

AI_CONFIG = {
    "api_key": "a773de80-b0c6-4430-b8f0-80e28aaecccd",
    "base_url": "https://ark.cn-beijing.volces.com/api/v3",
    "model": "doubao-seed-1-8-251228"
}

def get_ai_client():
    """获取AI客户端"""
    if not OPENAI_AVAILABLE:
        return None
    
    try:
        client = OpenAI(
            api_key=AI_CONFIG["api_key"],
            base_url=AI_CONFIG["base_url"]
        )
        return client
    except Exception as e:
        print(f"创建AI客户端失败: {e}")
        return None

def ai_summarize_messages(messages: List[str], summary_type: str = "daily") -> Dict[str, Any]:
    """
    使用AI智能总结消息
    
    Args:
        messages: 消息列表
        summary_type: daily/weekly/monthly
    
    Returns:
        dict: 包含总结内容
    """
    if not messages or len(messages) == 0:
        return {
            "success": False,
            "summary": "暂无讨论内容",
            "categories": {},
            "key_insights": [],
            "action_items": []
        }
    
    client = get_ai_client()
    if not client:
        return {
            "success": False,
            "summary": "AI服务不可用",
            "categories": {},
            "key_insights": [],
            "action_items": []
        }
    
    messages_text = "\n".join([f"- {msg}" for msg in messages[:50]])
    
    type_prompts = {
        "daily": "今日群聊讨论",
        "weekly": "本周群聊讨论",
        "monthly": "本月群聊讨论"
    }
    
    prompt = f"""你是一个专业的会议纪要助手。请分析以下{type_prompts.get(summary_type, '群聊讨论')}内容，生成一份智能总结。

要求：
1. **不要直接摘抄原文**，而是理解后用自己的话总结
2. 提取核心观点和关键信息
3. 发现讨论中的共性和规律
4. 给出有价值的见解和建议
5. 语言要流畅、专业、有深度

讨论内容：
{messages_text}

请按以下JSON格式输出（不要有其他内容）：
{{
    "summary": "整体总结（2-3句话，概括核心内容）",
    "categories": {{
        "主题1": "该主题的智能总结（不是摘抄，而是提炼后的内容）",
        "主题2": "该主题的智能总结"
    }},
    "key_insights": [
        "关键洞察1（有深度的见解）",
        "关键洞察2"
    ],
    "action_items": [
        "建议行动1",
        "建议行动2"
    ]
}}
"""
    
    try:
        response = client.chat.completions.create(
            model=AI_CONFIG["model"],
            messages=[
                {"role": "system", "content": "你是一个专业的会议纪要助手，擅长从讨论中提炼核心观点和有价值的信息。"},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=2000
        )
        
        content = response.choices[0].message.content.strip()
        
        json_match = re.search(r'\{[\s\S]*\}', content)
        if json_match:
            result = json.loads(json_match.group())
            result["success"] = True
            return result
        else:
            return {
                "success": True,
                "summary": content[:300],
                "categories": {},
                "key_insights": [],
                "action_items": []
            }
    
    except Exception as e:
        print(f"AI总结失败: {e}")
        return {
            "success": False,
            "summary": f"AI总结失败: {str(e)}",
            "categories": {},
            "key_insights": [],
            "action_items": []
        }

def ai_generate_inspiration(keywords: List[str], context: str = "") -> str:
    """
    使用AI生成智能金句/建议
    
    Args:
        keywords: 关键词列表
        context: 上下文内容
    
    Returns:
        str: 金句或建议
    """
    client = get_ai_client()
    if not client:
        return "💡 每天进步一点点，实现复利的力量！"
    
    prompt = f"""基于以下关键词和上下文，生成一句有深度、有启发的金句或建议。

关键词：{', '.join(keywords[:5])}
上下文：{context[:200] if context else '群聊讨论'}

要求：
1. 简洁有力，不超过50字
2. 有深度，能引发思考
3. 与讨论内容相关
4. 格式：💡 名字：金句内容

直接输出金句，不要其他内容。
"""
    
    try:
        response = client.chat.completions.create(
            model=AI_CONFIG["model"],
            messages=[
                {"role": "system", "content": "你是一个智慧导师，擅长给出有深度的金句和建议。"},
                {"role": "user", "content": prompt}
            ],
            temperature=0.9,
            max_tokens=100
        )
        
        return response.choices[0].message.content.strip()
    
    except Exception as e:
        print(f"AI生成金句失败: {e}")
        return "💡 每天进步一点点，实现复利的力量！"

def ai_categorize_and_summarize(messages: List[str]) -> Dict[str, Any]:
    """
    AI智能分类和总结
    
    Args:
        messages: 消息列表
    
    Returns:
        dict: 分类和总结结果
    """
    if not messages or len(messages) == 0:
        return {
            "success": False,
            "categories": {},
            "summary": "暂无讨论内容"
        }
    
    client = get_ai_client()
    if not client:
        return {
            "success": False,
            "categories": {},
            "summary": "AI服务不可用"
        }
    
    messages_text = "\n".join([f"- {msg}" for msg in messages[:30]])
    
    prompt = f"""请分析以下群聊内容，进行智能分类和总结。

要求：
1. 将内容按主题分类（如：工作讨论、问题求助、经验分享、决策事项等）
2. 每个分类给出一个智能总结（不是摘抄，而是提炼后的内容）
3. 总结要体现讨论的核心观点和价值

讨论内容：
{messages_text}

请按以下JSON格式输出：
{{
    "categories": {{
        "分类名称": "该分类的智能总结（不是摘抄，而是提炼后的内容）"
    }},
    "summary": "整体总结（2-3句话）"
}}
"""
    
    try:
        response = client.chat.completions.create(
            model=AI_CONFIG["model"],
            messages=[
                {"role": "system", "content": "你是一个专业的会议纪要助手，擅长分类和总结讨论内容。"},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=1500
        )
        
        content = response.choices[0].message.content.strip()
        
        json_match = re.search(r'\{[\s\S]*\}', content)
        if json_match:
            result = json.loads(json_match.group())
            result["success"] = True
            return result
        else:
            return {
                "success": True,
                "categories": {},
                "summary": content[:300]
            }
    
    except Exception as e:
        print(f"AI分类总结失败: {e}")
        return {
            "success": False,
            "categories": {},
            "summary": f"AI分类总结失败: {str(e)}"
        }

if __name__ == "__main__":
    test_messages = [
        "求助这个要怎么回，怎么延伸话题",
        "有一些朋友圈，地区都问过的，有一搭没一搭的在聊的，要重新破冰怎么破",
        "感觉破冰话术没问题，就是没有挑出引起客户兴趣的话题",
        "等话题，多听听客户表达的事情，在分享一些相同的事情"
    ]
    
    print("测试AI智能总结...")
    result = ai_summarize_messages(test_messages, "daily")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    
    print("\n测试AI生成金句...")
    inspiration = ai_generate_inspiration(["破冰", "话题", "客户"], "讨论如何与客户破冰和延伸话题")
    print(inspiration)
