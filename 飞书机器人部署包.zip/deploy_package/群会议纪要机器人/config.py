# 群会议纪要机器人配置文件
# ==================== 基础配置 ====================

FEISHU_APP_ID = "cli_a9233dfe18389bde"
FEISHU_APP_SECRET = "8gvZm8C04sS0GJXtDQdkkeAOJV6gCr4w"

# ==================== 测试模式配置 ====================

TEST_MODE = False
TEST_GROUP = "张贤良测试群"

# ==================== 发送时间配置（分时段方案）====================
# 设计原则：日报晚上发，周报/月报早上发，完全避免冲突

DAILY_TIME = "21:00"
WEEKLY_TIME = "09:00"
MONTHLY_TIME = "09:30"

# ==================== 群组配置 ====================

SEND_MODE = "all"

WHITELIST_GROUPS = []

BLACKLIST_GROUPS = [
    "张贤良测试群",
]

# ==================== 智能过滤配置 ====================

SKIP_EMPTY_GROUPS = True
MIN_MESSAGE_COUNT = 3
SKIP_SYSTEM_ONLY = True

# ==================== 报告格式配置 ====================

REPORT_FORMAT = "simple"
SHOW_GENERATE_TIME = True
SHOW_BOT_SIGNATURE = True
BOT_NAME = "群会议纪要"

# ==================== 调试配置 ====================

DEBUG_MODE = False
DEBUG_GROUP = "张贤良测试群"
