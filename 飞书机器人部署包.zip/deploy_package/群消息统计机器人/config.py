#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""群消息统计机器人配置文件"""

# ==================== 基础配置 ====================

FEISHU_APP_ID = "cli_a92aab4685f9dbc7"
FEISHU_APP_SECRET = "kjoKDg6QN3fcR58IvLj8WeK3YwkRwsXO"

# ==================== 测试模式配置 ====================

TEST_MODE = False
TEST_GROUP = "张贤良测试群"

# ==================== 发送时间配置（分时段方案）====================

DAILY_TIME = "09:00"
WEEKLY_TIME = "12:00"
MONTHLY_TIME = "15:00"

# ==================== 群组配置 ====================

GROUP_CHATS = {
    "人力资源部": {
        "id": "oc_da7e756b1341d0ae99461aec727098c9",
        "enabled": True
    },
    "视效部": {
        "id": "oc_fd7f88f0cc434260b1cdab8a7965416d",
        "enabled": True
    },
    "视效AI研究小队": {
        "id": "oc_618df580458c6d42b1b2358e4e24c933",
        "enabled": True
    },
    "策划一组": {
        "id": "oc_bb817774c9b04c98003f941596f481bd",
        "enabled": True
    },
    "策划三部": {
        "id": "oc_e7b8da4b67e96194498330ac8ceaf0ca",
        "enabled": True
    },
    "策划二部": {
        "id": "oc_25f38870e584f38e574f8cb3d2b4e032",
        "enabled": True
    },
    "项目市场二部": {
        "id": "oc_31f4ff6b646065162f21ae2a8701675f",
        "enabled": True
    },
    "项目一部": {
        "id": "oc_311fd123179ee09de1127c91ed711b32",
        "enabled": True
    },
    "视效月会": {
        "id": "oc_3e3eea499c413364bb5eabe73670b20e",
        "enabled": True
    },
    "做大做强做稳": {
        "id": "oc_add2b6d457c2f84d900c997b3e6a324b",
        "enabled": True
    },
    "饿狼传说": {
        "id": "oc_320970934bacf5066061a2aa6465051a",
        "enabled": True
    },
    "福气满溢": {
        "id": "oc_3938fde406608c4063e03f5e44c3b169",
        "enabled": True
    },
    "个人测试群组": {
        "id": "oc_564b0cec9170bd807162b87c9b05a90e",
        "enabled": False
    },
    "英璨市场部大群": {
        "id": "oc_48e2db5c69667ddfe1a50331939f98e1",
        "enabled": True
    },
    "张贤良测试群": {
        "id": "oc_564b0cec9170bd807162b87c9b05a90e",
        "enabled": True
    }
}

SEND_MODE = "config"
WHITELIST_GROUPS = []
BLACKLIST_GROUPS = ["个人测试群组"]

# ==================== 排除配置 ====================

CEO_LIST = {"张贤良", "蒋文卿"}

# ==================== 重试配置 ====================

MAX_RETRIES = 3
RETRY_INTERVAL = 300

# ==================== 报告配置 ====================

SHOW_GENERATE_TIME = True
SHOW_BOT_SIGNATURE = True
BOT_NAME = "群消息统计机器人"

# ==================== 调试配置 ====================

DEBUG_MODE = False
DEBUG_GROUP = "个人测试群组"
