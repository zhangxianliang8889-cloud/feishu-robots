#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""模拟测试脚本 - 使用模拟聊天内容生成日报、周报、月报"""

import requests
import json
import re
from datetime import datetime, timedelta
from collections import Counter
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import *

NO_PROXY = {}

MOBILE_CHAT_CONTENT = """[09:00] 张贤良: "跨4级招人"的招聘方式。
[09:05] 张贤良: 理念：招的时候要慎重，招来以后要欣赏
[09:10] 李明: 适合大于优秀，选择大于培养。
[09:15] 张贤良: 冰山下面是管理者不能直接看出来的：能力、潜力、态度、价值观、社会角色、个性品质、动机、内驱力等。这些需要管理者在面试时，通过设计的问题来了解。
[09:20] 王芳: 图3-8-6 阿里"北斗七星"选人法的金字塔构成
[09:25] 张贤良: 在了解了其架构后，我们来看看这7个关键词分别代表着什么。
[09:30] 李明: 诚信：毋庸置疑，一个人如果不具备诚信，他的能力就犹如空中楼阁，一切都是虚幻。所以诚信是"北斗七星"选人法的金字塔的最底层的逻辑。
[09:35] 王芳: 要强：一个人要有自我成长和事业成功方面的目标，不能太"佛系"。
[09:40] 张贤良: 目标忠诚度：设置有挑战性和可行性的短期和长期目标，保持对目标的忠诚和专注，通过踏实工作促进目标的实现。
[09:45] 李明: 喜欢干销售：管理者在招聘销售岗位的员工时，这个人要认为销售工作有意义、有价值，视销售为自己的职业和未来，对销售工作感兴趣并愿意从事销售工作。
[09:50] 王芳: 又猛又持久：这是阿里的"土话"，意思是说这个人要具有吃苦耐劳、勤奋务实的品质，同时抗压能力强，能乐观面对挫折和困难，善于控制情绪，保持积极心态。
[09:55] 张贤良: OPEN：是指这个人要乐于与人沟通，并且易于相处，能够与客户、团队成员、领导和谐地相处，建立良好的人际关系。
[10:00] 李明: 悟性：悟性作为金字塔的顶端，足以看出阿里对它的重视。悟性是指一个人的学习能力和思维能力，在工作的过程中，能对工作的知识和经验不断吸收、归纳、演绎和迁移，并最终拿结果说话。
[10:05] 王芳: 通过以上对"北斗七星"选人法7个关键词的描述，我们可以清晰地看出，阿里关于一个岗位的人才画像是非常清晰的。
[10:10] 张贤良: 然而，让我感到遗憾的是，在我服务的企业里（特别是中小企业），大多是没有自己的"人才画像"的。
[10:15] 李明: 所以，管理者在招人时，要向阿里学习，设计好人才画像，让招人的工作兼顾道和术的层面。
[10:20] 王芳: 人才来源："上下左右"人才渠道
[10:25] 张贤良: 管理者要想迅速招到想要的人才，必须清楚自己的人才来源，也就是从哪里招。
[10:30] 李明: 根据阿里和我现在招人的经验总结，我归纳出人才来源集中在"上下左右"4个渠道。
[10:35] 王芳: "上"是指线上招聘，例如智联招聘、51Job等综合招聘平台，58同城、拉钩等垂直招聘平台；北京人才网、重庆人才网等地域招聘平台。
[10:40] 张贤良: "下"是指线下招聘，如校园招聘、人才市场招聘等线下实体招聘平台。
[10:45] 李明: "左"是指团队内部推荐，这一方式需要建立相应的内推制度，营造内推氛围。
[10:50] 王芳: "右"是指在同行内进行挖掘，或是通过猎头机构高薪挖人。
[10:55] 张贤良: 建议我们公司也建立自己的人才画像体系。
[11:00] 李明: 同意，这样可以提高招聘效率和质量。
[11:05] 王芳: 我可以负责设计销售岗位的人才画像。
[11:10] 张贤良: 好的，王芳你先出一个方案，下周我们讨论。
[11:15] 李明: 需要跟进这个事情的进度。
[11:20] 王芳: 收到，我会尽快完成方案。"""

def get_feishu_token():
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    data = {"app_id": FEISHU_APP_ID, "app_secret": FEISHU_APP_SECRET}
    try:
        r = requests.post(url, json=data, timeout=10, proxies=NO_PROXY)
        r.raise_for_status()
        response = r.json()
        if "tenant_access_token" in response:
            return response["tenant_access_token"]
        else:
            print(f"❌ 获取Token失败: {response}")
            return None
    except Exception as e:
        print(f"❌ 获取Token时发生错误: {e}")
        return None

def get_bot_groups(token):
    url = "https://open.feishu.cn/open-apis/im/v1/chats"
    headers = {"Authorization": f"Bearer {token}"}
    params = {"page_size": 100}
    
    try:
        r = requests.get(url, headers=headers, params=params, timeout=10, proxies=NO_PROXY)
        r.raise_for_status()
        response = r.json()
        
        if response.get("code") == 0:
            data = response.get("data", {})
            return data.get("items", [])
        else:
            print(f"⚠️ 获取群列表失败: {response}")
            return []
    except Exception as e:
        print(f"⚠️ 获取群列表时发生错误: {e}")
        return []

def generate_ai_summary(lines, total_messages, summary_type="daily", chat_name="", date_range=""):
    """使用主程序的完整AI总结逻辑"""
    participants = set()
    tasks = []
    decisions = []
    important_info = []
    questions = []
    suggestions = []
    links = []
    keywords = []
    topics = []
    
    task_patterns = [
        r'需要(.{2,20})',
        r'要(.{2,20})',
        r'请(.{2,20})',
        r'帮忙(.{2,20})',
        r'完成(.{2,20})',
        r'处理(.{2,20})',
        r'跟进(.{2,20})',
        r'安排(.{2,20})',
        r'准备(.{2,20})',
        r'待办[:：](.{2,30})',
        r'TODO[:：](.{2,30})',
    ]
    
    decision_patterns = [
        r'确定(.{2,30})',
        r'同意(.{2,20})',
        r'确认(.{2,30})',
        r'定下来(.{2,20})',
        r'就这么定了',
        r'通过(.{2,20})',
    ]
    
    important_patterns = [
        r'重要[:：](.{2,50})',
        r'注意[:：](.{2,50})',
        r'提醒(.{2,30})',
        r'通知[:：](.{2,50})',
    ]
    
    question_patterns = [
        r'(.{2,10})\?',
        r'(.{2,10})？',
        r'怎么(.{2,20})',
        r'如何(.{2,20})',
        r'为什么(.{2,20})',
        r'有没有(.{2,20})',
    ]
    
    suggestion_patterns = [
        r'建议(.{2,30})',
        r'可以(.{2,20})',
        r'试试(.{2,20})',
        r'不如(.{2,20})',
        r'推荐(.{2,20})',
    ]
    
    stop_words = {'的', '了', '是', '在', '有', '和', '就', '不', '人', '都', 
                  '一', '一个', '上', '也', '很', '到', '说', '要', '去', '你',
                  '会', '着', '没有', '看', '好', '自己', '这', '那', '什么',
                  '吗', '呢', '吧', '啊', '嗯', '哦', '哈', '呀', '额', '这个',
                  '那个', '可以', '可能', '应该', '还是', '但是', '因为', '所以',
                  '大家', '早上好', '好的', '收到', '谢谢', '感谢', '没问题',
                  '今天', '明天', '昨天', '下午', '上午', '晚上', '几点', '开始',
                  '什么', '怎么', '哪里', '多少', '怎样', '如何', '为什么',
                  '总新闻数', 'AI分析数', '时间', '类型', '简报', '热点早报',
                  '测试推送', '老板专属', '每日资讯', 'This', 'message', 'was',
                  'recalled', '消息撤回', '═══', '════════', '════════════════════════════════════════'}
    
    for line in lines:
        match = re.match(r'\[(\d{2}:\d{2})\]\s*(.+?):\s*(.+)', line)
        if match:
            time, sender, content = match.groups()
            participants.add(sender)
            
            for pattern in task_patterns:
                task_match = re.search(pattern, content)
                if task_match:
                    tasks.append(task_match.group(0).strip())
                    break
            
            for pattern in decision_patterns:
                decision_match = re.search(pattern, content)
                if decision_match:
                    decisions.append(decision_match.group(0).strip())
                    break
            
            for pattern in important_patterns:
                info_match = re.search(pattern, content)
                if info_match:
                    important_info.append(info_match.group(0).strip())
                    break
            
            for pattern in question_patterns:
                q_match = re.search(pattern, content)
                if q_match:
                    questions.append(q_match.group(0).strip())
                    break
            
            for pattern in suggestion_patterns:
                s_match = re.search(pattern, content)
                if s_match:
                    suggestions.append(s_match.group(0).strip())
                    break
            
            url_match = re.search(r'https?://[^\s]+', content)
            if url_match:
                links.append(url_match.group(0))
            
            words = re.findall(r'[\u4e00-\u9fa5]{2,8}', content)
            for word in words:
                if (word not in stop_words and 
                    len(word) >= 2 and 
                    not word.startswith('关于') and
                    not re.match(r'^[0-9]+$', word) and
                    not word.startswith('═')):
                    keywords.append(word)
            
            if len(content) > 10 and not content.startswith('**') and 'http' not in content:
                clean_content = re.sub(r'[【\[\(].*?[\]\)】]', '', content)
                clean_content = re.sub(r'\*+', '', clean_content)
                clean_content = re.sub(r'═+', '', clean_content)
                clean_content = clean_content.strip()
                if len(clean_content) > 5 and clean_content not in ['This message was recalled']:
                    topics.append(clean_content[:30])
    
    keyword_freq = Counter(keywords).most_common(10)
    top_keywords = [word for word, _ in keyword_freq[:5]]
    
    participant_count = len(participants)
    
    if summary_type == "daily":
        return generate_daily_summary(participant_count, total_messages, topics, top_keywords, decisions, tasks, links, chat_name, date_range)
    elif summary_type == "weekly":
        return generate_weekly_summary(participant_count, total_messages, topics, top_keywords, decisions, tasks, links, questions, suggestions, participants, chat_name, date_range)
    else:
        return generate_monthly_summary(participant_count, total_messages, topics, top_keywords, decisions, tasks, links, questions, suggestions, participants, chat_name, date_range)

def generate_daily_summary(participant_count, total_messages, topics, top_keywords, decisions, tasks, links, chat_name="", date_range=""):
    """生成日报格式"""
    summary_parts = []
    
    if chat_name and date_range:
        summary_parts.append(f"📊 {chat_name} - 群会议纪要日报 ({date_range})")
        summary_parts.append("")
    
    summary_parts.append("═" * 40)
    summary_parts.append(f"📈 今日数据：{total_messages} 条消息 | {participant_count} 人参与")
    summary_parts.append("═" * 40)
    summary_parts.append("")
    
    summary_parts.append("📌 今日要点")
    summary_parts.append("─" * 40)
    if topics:
        unique_topics = []
        for t in topics[:10]:
            is_dup = False
            for ut in unique_topics:
                if t[:15] in ut or ut[:15] in t:
                    is_dup = True
                    break
            if not is_dup and len(unique_topics) < 5:
                unique_topics.append(t)
        
        for topic in unique_topics:
            summary_parts.append(f"• {topic}")
    elif top_keywords:
        for kw in top_keywords[:5]:
            summary_parts.append(f"• {kw}")
    else:
        summary_parts.append("• 暂无具体讨论内容")
    summary_parts.append("")
    
    summary_parts.append("✅ 完成事项")
    summary_parts.append("─" * 40)
    if decisions:
        for d in decisions[:3]:
            summary_parts.append(f"• {d}")
    else:
        summary_parts.append("• 暂无")
    summary_parts.append("")
    
    summary_parts.append("📋 待办事项")
    summary_parts.append("─" * 40)
    if tasks:
        for t in tasks[:3]:
            summary_parts.append(f"• {t}")
    else:
        summary_parts.append("• 暂无")
    summary_parts.append("")
    
    summary_parts.append("📎 相关链接")
    summary_parts.append("─" * 40)
    if links:
        for link in links[:2]:
            summary_parts.append(f"• {link[:50]}...")
    else:
        summary_parts.append("• 暂无")
    summary_parts.append("")
    
    summary_parts.append("═" * 40)
    if top_keywords:
        summary_parts.append(f"💡 今日总结：群聊主要围绕「{'、'.join(top_keywords[:3])}」展开，共{participant_count}人参与。")
    else:
        summary_parts.append(f"💡 今日总结：共{participant_count}人参与，产生{total_messages}条消息。")
    summary_parts.append("═" * 40)
    summary_parts.append("")
    
    if total_messages > 0:
        summary_parts.append("🌟 感谢大家的积极参与！每一条消息都是智慧的火花！")
    else:
        summary_parts.append("🔔 今天有点安静哦，期待大家分享想法和见解！")
    summary_parts.append("")
    summary_parts.append("🌈 这里是我们灵感碰撞的地方！💪 勇于表达，让群智涌现！")
    
    return '\n'.join(summary_parts)

def generate_weekly_summary(participant_count, total_messages, topics, top_keywords, decisions, tasks, links, questions, suggestions, participants, chat_name="", date_range=""):
    """生成周报格式"""
    summary_parts = []
    
    if chat_name and date_range:
        summary_parts.append(f"📊 {chat_name} - 群会议纪要周报 ({date_range})")
        summary_parts.append("")
    
    summary_parts.append("═" * 40)
    summary_parts.append(f"📈 本周数据：{total_messages} 条消息 | {participant_count} 人参与 | 日均 {total_messages // 7 if total_messages > 0 else 0} 条")
    summary_parts.append("═" * 40)
    summary_parts.append("")
    
    summary_parts.append("📌 本周重点讨论")
    summary_parts.append("─" * 40)
    if topics:
        unique_topics = []
        for t in topics[:15]:
            is_dup = False
            for ut in unique_topics:
                if t[:15] in ut or ut[:15] in t:
                    is_dup = True
                    break
            if not is_dup and len(unique_topics) < 8:
                unique_topics.append(t)
        
        for topic in unique_topics:
            summary_parts.append(f"• {topic}")
    elif top_keywords:
        for kw in top_keywords[:8]:
            summary_parts.append(f"• {kw}")
    else:
        summary_parts.append("• 暂无具体讨论内容")
    summary_parts.append("")
    
    summary_parts.append("✅ 本周决议")
    summary_parts.append("─" * 40)
    if decisions:
        for d in decisions[:5]:
            summary_parts.append(f"• {d}")
    else:
        summary_parts.append("• 暂无")
    summary_parts.append("")
    
    summary_parts.append("📋 待跟进事项")
    summary_parts.append("─" * 40)
    if tasks:
        for t in tasks[:5]:
            summary_parts.append(f"• {t}")
    else:
        summary_parts.append("• 暂无")
    summary_parts.append("")
    
    summary_parts.append("❓ 本周疑问")
    summary_parts.append("─" * 40)
    if questions:
        unique_q = list(set(questions))[:3]
        for q in unique_q:
            summary_parts.append(f"• {q}")
    else:
        summary_parts.append("• 暂无")
    summary_parts.append("")
    
    summary_parts.append("💡 建议与想法")
    summary_parts.append("─" * 40)
    if suggestions:
        unique_s = list(set(suggestions))[:3]
        for s in unique_s:
            summary_parts.append(f"• {s}")
    else:
        summary_parts.append("• 暂无")
    summary_parts.append("")
    
    summary_parts.append("═" * 40)
    summary_parts.append("📊 本周复盘")
    summary_parts.append("═" * 40)
    
    if participant_count >= 5 and total_messages >= 50:
        summary_parts.append("• 本周交流活跃，团队协作良好")
        summary_parts.append("• 建议继续保持，可尝试更深入的话题讨论")
    elif participant_count >= 3 and total_messages >= 20:
        summary_parts.append("• 本周有一定交流，团队氛围不错")
        summary_parts.append("• 建议鼓励更多成员参与讨论")
    else:
        summary_parts.append("• 本周交流较少，可考虑增加互动话题")
        summary_parts.append("• 建议定期分享有价值的内容，激发讨论")
    
    if len(tasks) > 3:
        summary_parts.append(f"• 有{len(tasks)}项待办事项，建议及时跟进")
    
    summary_parts.append("")
    
    summary_parts.append("═" * 40)
    if top_keywords:
        summary_parts.append(f"🎯 周总结：本周主要围绕「{'、'.join(top_keywords[:3])}」展开讨论。")
    else:
        summary_parts.append(f"🎯 周总结：本周共{participant_count}人参与，产生{total_messages}条消息。")
    summary_parts.append("═" * 40)
    summary_parts.append("")
    
    if total_messages > 0:
        summary_parts.append("🌟 感谢本周所有参与讨论的伙伴！你们让群更有价值！")
    else:
        summary_parts.append("🔔 本周有点安静，期待下周大家分享更多见解！")
    summary_parts.append("")
    summary_parts.append("🌈 这里是我们灵感碰撞的地方！💪 勇于表达，让群智涌现！")
    
    return '\n'.join(summary_parts)

def generate_monthly_summary(participant_count, total_messages, topics, top_keywords, decisions, tasks, links, questions, suggestions, participants, chat_name="", date_range=""):
    """生成月报格式"""
    import calendar
    
    summary_parts = []
    
    now = datetime.now()
    days_in_month = calendar.monthrange(now.year, now.month)[0] if now.month > 1 else calendar.monthrange(now.year - 1, 12)[1]
    
    if chat_name and date_range:
        summary_parts.append(f"📈 {chat_name} - 群会议纪要月报 ({date_range})")
        summary_parts.append("")
    
    summary_parts.append("═" * 40)
    summary_parts.append(f"📈 本月数据：{total_messages} 条消息 | {participant_count} 人参与 | 日均 {total_messages // days_in_month if total_messages > 0 else 0} 条")
    summary_parts.append("═" * 40)
    summary_parts.append("")
    
    summary_parts.append("📌 本月核心话题")
    summary_parts.append("─" * 40)
    if topics:
        unique_topics = []
        for t in topics[:20]:
            is_dup = False
            for ut in unique_topics:
                if t[:15] in ut or ut[:15] in t:
                    is_dup = True
                    break
            if not is_dup and len(unique_topics) < 10:
                unique_topics.append(t)
        
        for topic in unique_topics:
            summary_parts.append(f"• {topic}")
    elif top_keywords:
        for kw in top_keywords[:10]:
            summary_parts.append(f"• {kw}")
    else:
        summary_parts.append("• 暂无具体讨论内容")
    summary_parts.append("")
    
    summary_parts.append("✅ 本月重要决议")
    summary_parts.append("─" * 40)
    if decisions:
        for d in decisions[:5]:
            summary_parts.append(f"• {d}")
    else:
        summary_parts.append("• 暂无")
    summary_parts.append("")
    
    summary_parts.append("📋 待跟进事项")
    summary_parts.append("─" * 40)
    if tasks:
        for t in tasks[:5]:
            summary_parts.append(f"• {t}")
    else:
        summary_parts.append("• 暂无")
    summary_parts.append("")
    
    summary_parts.append("💡 本月建议汇总")
    summary_parts.append("─" * 40)
    if suggestions:
        unique_s = list(set(suggestions))[:5]
        for s in unique_s:
            summary_parts.append(f"• {s}")
    else:
        summary_parts.append("• 暂无")
    summary_parts.append("")
    
    summary_parts.append("═" * 40)
    summary_parts.append("📊 月度复盘")
    summary_parts.append("═" * 40)
    
    avg_daily = total_messages / days_in_month if days_in_month > 0 else 0
    
    if avg_daily >= 10:
        summary_parts.append("• 本月交流非常活跃，团队凝聚力强")
        summary_parts.append("• 建议保持良好势头，可尝试更深入的项目讨论")
    elif avg_daily >= 5:
        summary_parts.append("• 本月交流较为活跃，团队氛围良好")
        summary_parts.append("• 建议继续鼓励成员分享，提升讨论质量")
    elif avg_daily > 0:
        summary_parts.append("• 本月有一定交流，但仍有提升空间")
        summary_parts.append("• 建议定期组织话题讨论，激发群智涌现")
    else:
        summary_parts.append("• 本月交流较少，建议关注团队沟通")
        summary_parts.append("• 可尝试设置固定话题时间，促进交流")
    
    if len(tasks) > 5:
        summary_parts.append(f"• 有{len(tasks)}项待办事项，建议梳理优先级")
    
    summary_parts.append("")
    
    summary_parts.append("═" * 40)
    if top_keywords:
        summary_parts.append(f"🎯 月总结：本月主要围绕「{'、'.join(top_keywords[:5])}」展开讨论。")
    else:
        summary_parts.append(f"🎯 月总结：本月共{participant_count}人参与，产生{total_messages}条消息。")
    summary_parts.append("═" * 40)
    summary_parts.append("")
    
    if total_messages > 0:
        summary_parts.append("🌟 感谢本月所有参与讨论的伙伴！你们让群更有价值！")
    else:
        summary_parts.append("🔔 本月有点安静，期待下个月大家分享更多见解！")
    summary_parts.append("")
    summary_parts.append("🚀 下月展望：期待更多精彩讨论，群智涌现！")
    summary_parts.append("")
    summary_parts.append("🌈 这里是我们灵感碰撞的地方！💪 勇于表达，让群智涌现！")
    
    return '\n'.join(summary_parts)

def send_message_to_group(token, chat_id, message_content):
    url = "https://open.feishu.cn/open-apis/im/v1/messages"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    params = {
        "receive_id_type": "chat_id"
    }
    
    data = {
        "receive_id": chat_id,
        "msg_type": "text",
        "content": json.dumps({"text": message_content})
    }
    
    try:
        r = requests.post(url, headers=headers, params=params, json=data, timeout=10, proxies=NO_PROXY)
        r.raise_for_status()
        result = r.json()
        
        if result.get("code") == 0:
            return True
        else:
            print(f"❌ 消息发送失败: {result}")
            return False
    except Exception as e:
        print(f"❌ 发送消息时发生错误: {e}")
        return False

def main():
    print("=" * 60)
    print("🧪 模拟测试脚本 - 日报/周报/月报")
    print("=" * 60)
    print()
    
    print("🔑 获取飞书Token...")
    token = get_feishu_token()
    if not token:
        print("❌ Token获取失败，退出")
        return
    print("✅ Token获取成功")
    print()
    
    print("📋 获取机器人所在群列表...")
    groups = get_bot_groups(token)
    print(f"✅ 机器人共在 {len(groups)} 个群中")
    print()
    
    test_group = None
    for group in groups:
        if group.get("name") == "张贤良测试群":
            test_group = group
            break
    
    if not test_group:
        print("❌ 未找到张贤良测试群")
        return
    
    chat_id = test_group.get("chat_id")
    chat_name = test_group.get("name")
    print(f"🎯 找到测试群: {chat_name}")
    print(f"   Chat ID: {chat_id}")
    print()
    
    lines = MOBILE_CHAT_CONTENT.strip().split('\n')
    total_messages = len(lines)
    
    now = datetime.now()
    
    print("=" * 60)
    print("📅 发送日报")
    print("=" * 60)
    date_range = now.strftime('%Y-%m-%d')
    daily_summary = generate_ai_summary(lines, total_messages, summary_type="daily", chat_name=chat_name, date_range=date_range)
    print("📤 发送日报到测试群...")
    if send_message_to_group(token, chat_id, daily_summary):
        print("✅ 日报发送成功！")
    else:
        print("❌ 日报发送失败")
    print()
    
    print("=" * 60)
    print("📊 发送周报")
    print("=" * 60)
    monday = now - timedelta(days=now.weekday())
    start_of_week = monday - timedelta(weeks=1)
    end_of_week = monday - timedelta(days=1)
    date_range = f"{start_of_week.strftime('%Y-%m-%d')} ~ {end_of_week.strftime('%Y-%m-%d')}"
    weekly_summary = generate_ai_summary(lines, total_messages, summary_type="weekly", chat_name=chat_name, date_range=date_range)
    print("📤 发送周报到测试群...")
    if send_message_to_group(token, chat_id, weekly_summary):
        print("✅ 周报发送成功！")
    else:
        print("❌ 周报发送失败")
    print()
    
    print("=" * 60)
    print("📈 发送月报")
    print("=" * 60)
    first_of_month = now.replace(day=1)
    start_of_month = (first_of_month - timedelta(days=1)).replace(day=1)
    date_range = start_of_month.strftime('%Y-%m')
    monthly_summary = generate_ai_summary(lines, total_messages, summary_type="monthly", chat_name=chat_name, date_range=date_range)
    print("📤 发送月报到测试群...")
    if send_message_to_group(token, chat_id, monthly_summary):
        print("✅ 月报发送成功！")
    else:
        print("❌ 月报发送失败")
    print()
    
    print("=" * 60)
    print("🎉 测试完成")
    print("=" * 60)

if __name__ == "__main__":
    main()
