#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
群消息统计机器人配置文件
设计原则：动态获取所有群，统一排除测试群
"""

# ==================== 基础配置 ====================

FEISHU_APP_ID = "cli_a92aab4685f9dbc7"
FEISHU_APP_SECRET = "kjoKDg6QN3fcR58IvLj8WeK3YwkRwsXO"

# ==================== 发送时间配置 ====================
# 设计原则：与群会议纪要机器人完全错开

DAILY_TIME = "09:00"    # 日报：早上9点
WEEKLY_TIME = "12:00"   # 周报：中午12点
MONTHLY_TIME = "15:00"  # 月报：下午3点

# ==================== 群组管理配置 ====================
# 设计原则：动态获取所有群，统一排除测试群

SEND_MODE = "blacklist"

# 测试群列表（这些群不发送报告，测试时使用TEST_MODE）
BLACKLIST_GROUPS = [
    "张贤良测试群",
    "个人测试群组",
]

# ==================== 测试模式配置 ====================
# 启用后只发送到测试群，用于调试

TEST_MODE = False
TEST_GROUP = "张贤良测试群"

# ==================== CEO排除配置 ====================
# CEO不参与消息统计

CEO_LIST = {"张贤良", "蒋文卿"}

# ==================== 报告内容配置 ====================

SHOW_GENERATE_TIME = True
SHOW_BOT_SIGNATURE = True
BOT_NAME = "群消息统计机器人"

# ==================== 智能过滤配置 ====================

SKIP_EMPTY_GROUPS = True
MIN_MESSAGE_COUNT = 3
SKIP_SYSTEM_ONLY = True

# ==================== 重试配置 ====================

MAX_RETRIES = 3
RETRY_INTERVAL = 300  # 5分钟

# ==================== 调试配置 ====================

DEBUG_MODE = False
DEBUG_GROUP = "张贤良测试群"
