#!/bin/bash
# 飞书机器人快速启动脚本

echo "============================================================"
echo "🚀 飞书机器人快速启动脚本"
echo "============================================================"
echo ""

# 检查Python
if ! command -v python3 &> /dev/null; then
    echo "❌ 未安装Python3，请先安装"
    exit 1
fi

echo "✅ Python版本: $(python3 --version)"

# 安装依赖
echo ""
echo "📦 安装依赖..."
pip3 install requests schedule -q

# 检查screen
if ! command -v screen &> /dev/null; then
    echo "⚠️ 未安装screen，建议安装: yum install screen -y 或 apt install screen -y"
fi

echo ""
echo "============================================================"
echo "📋 请选择要启动的机器人："
echo "============================================================"
echo "1. 群会议纪要机器人"
echo "2. 群消息统计机器人"
echo "3. 同时启动两个机器人（守护进程）"
echo "4. 退出"
echo "============================================================"
echo ""

read -p "请输入选项 (1-4): " choice

case $choice in
    1)
        echo ""
        echo "🚀 启动群会议纪要机器人..."
        cd 群会议纪要机器人
        python3 群会议纪要_最终版.py
        ;;
    2)
        echo ""
        echo "🚀 启动群消息统计机器人..."
        cd 群消息统计机器人
        python3 多群统计.py
        ;;
    3)
        echo ""
        echo "🚀 启动守护进程管理器..."
        cd 群会议纪要机器人
        python3 start_daemon.py
        ;;
    4)
        echo "👋 退出"
        exit 0
        ;;
    *)
        echo "❌ 无效选项"
        exit 1
        ;;
esac
