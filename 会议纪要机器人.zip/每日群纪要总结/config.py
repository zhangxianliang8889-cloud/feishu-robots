#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
群会议纪要机器人配置文件
设计原则：动态获取所有群，统一排除测试群
"""

# ==================== 基础配置 ====================

FEISHU_APP_ID = "cli_a9233dfe18389bde"
FEISHU_APP_SECRET = "8gvZm8C04sS0GJXtDQdkkeAOJV6gCr4w"

# ==================== 发送时间配置 ====================
# 设计原则：与群消息统计机器人完全错开

DAILY_TIME = "21:00"    # 日报：晚上9点
WEEKLY_TIME = "10:00"   # 周报：上午10点（避开09:00）
MONTHLY_TIME = "14:00"  # 月报：下午2点（避开15:00）

# ==================== 群组管理配置 ====================
# 设计原则：动态获取所有群，统一排除测试群

SEND_MODE = "blacklist"

# 测试群列表（这些群不发送报告，测试时使用TEST_MODE）
BLACKLIST_GROUPS = [
    "张贤良测试群",
    "个人测试群组",
]

# ==================== 测试模式配置 ====================
# 启用后只发送到测试群，用于调试

TEST_MODE = False
TEST_GROUP = "张贤良测试群"

# ==================== 智能过滤配置 ====================

SKIP_EMPTY_GROUPS = True
MIN_MESSAGE_COUNT = 3
SKIP_SYSTEM_ONLY = True

# ==================== 报告格式配置 ====================

REPORT_FORMAT = "simple"
SHOW_GENERATE_TIME = True
SHOW_BOT_SIGNATURE = True
BOT_NAME = "群会议纪要"

# ==================== 调试配置 ====================

DEBUG_MODE = False
DEBUG_GROUP = "张贤良测试群"
